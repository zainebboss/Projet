/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudeformation;

import Entity.Cour;
import Entity.Formation;
import Service.ServiceCour;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 *
 * @author user
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField tfId_cour;
    @FXML
    private TextField tfId_formation;
    @FXML
    private TextField tfTitre;
    @FXML
    private TextField tfFichier;
    @FXML
    private TableView<?> tvcour;
    @FXML
    private TableColumn<Cour, Integer> colId_cour;
    @FXML
    private TableColumn<Formation, Integer> colId_formation;
    @FXML
    private TableColumn<Cour, String> colTitre;
    @FXML
    private TableColumn<Cour, String> colFichier;
    @FXML
    private Button btAjouter;
    @FXML
    private Button btModifier;
    @FXML
    private Button btSupprimer;
    @FXML
    private Button btAfficher;
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void AjouterCour(ActionEvent event) {
        ServiceCour sc = new ServiceCour();
        Cour C = new Cour();
        C.setTitre(tfTitre.getText());
        C.setFichier(tfFichier.getText());
        sc.AddCour (C);
    }

    @FXML
    private void ModifierCour(ActionEvent event) {
    }

    @FXML
    private void SupprimerCour(ActionEvent event) {
    }

    @FXML
    private void AfficherCour(ActionEvent event) {
         ServiceCour sc = new ServiceCour();
         tvcour.setAccessibleText(sc.AfficherCour().toString());
         
         
    }
    
}
