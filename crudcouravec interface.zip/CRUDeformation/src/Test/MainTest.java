/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Entity.Cour;
import Service.ServiceCour;
import java.util.List;

/**
 *
 * @author user
 */
public class MainTest {public static void main(String[] args) {
        // TODO code application logic here
        ServiceCour sc = new ServiceCour();
        
        Cour c1 = new Cour();
        c1.setTitre("titre");
        c1.setFichier("ficher");
    List<Cour> list =sc.AfficherCour();
            System.out.println(list);
       
       sc.AddCour(c1);
}}
