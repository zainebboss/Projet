/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entity.Cour;
import Services.IServiceCour;
import Utils.Maconnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;




public class ServiceCour implements IServiceCour{
Connection cnx; 
    private List<Cour> Cour;

    public ServiceCour() {
      cnx = (Connection) Maconnexion.getInstance().getConnection();
        
    }

    @Override
    public void AddCour(Cour C) {
    try {
        Statement stm = cnx.createStatement();
    
    
    String query =" INSERT INTO `cours`( `titre`, `fichier`) VALUES ('"+C.getTitre()+", "+C.getFichier()+"')";
    
    stm.executeUpdate(query);
    }
    catch (SQLException ex) {
        Logger.getLogger(ServiceCour.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    @Override
    public List<Cour> AfficherCour() {
    try {
       Statement stm = cnx.createStatement();
     
       String query = "select * from `cours`";
       ResultSet rst = stm.executeQuery(query);
       
       List<Cour> cour = new ArrayList <>();
       while(rst.next())
        {
            Cour C = new Cour();
        C.setTitre(rst.getString("Titre"));
       C.setFichier(rst.getString("Fichier"));
             Cour.add(C);
            
            
            
        }
    } catch (SQLException ex) {
        Logger.getLogger(ServiceCour.class.getName()).log(Level.SEVERE, null, ex);
    }
 
    return Cour;     
    }

    
    }
    

    








